<?php

namespace tung;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\plugin\PluginBase;

class Main extends PluginBase{

	public $repeattime = 5;
	/** @var string $answer */
	private $answer;
	/** @var PopupTask $task */
	private $task;

	public function onEnable(){
		$this->saveDefaultConfig();
		$this->reloadConfig();
		$this->getLogger()->info("ยงlยงdAnswer the question ");
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{

		$q = $this->getConfig()->get("Questions");
		$a = $this->getConfig()->get("Answers");

		switch(strtolower($command->getName())){
			case "ask":
				if(!isset($args[0])){
					$sender->sendMessage("Usage: /ask <number>");
					return false;
				}
				if(!is_numeric($args[0])){
					$sender->sendMessage("Usage: /ask <number>");
					return false;
				}
				$i = intval($args[0]);
				if(!in_array($i, array_keys($q))){
					$sender->sendMessage("Invalid question number.");
					return false;
				}
				$this->task = new PopupTask($this, $q[$i]);
				$this->getServer()->getScheduler()->scheduleRepeatingTask($this->task, $this->repeattime);
				$this->answer = $a[$i];
				return true;
			case "trl":
				if(!isset($args[0])){
					$sender->sendMessage("Usage: /trl <answer>");
					return false;
				}
				if(!isset($this->task)){
					$sender->sendMessage("There is no question currently running.");
					return false;
				}
				$answer = implode(" ", array_splice($args, 0, 999));
				if($answer === $this->answer){
					$this->getServer()->broadcastMessage($sender->getName() . " has the right answer.");
					$this->getServer()->getScheduler()->cancelTask($this->task->getTaskId());
					$this->getServer()->dispatchCommand(new ConsoleCommandSender(), "ask " . rand(0, count($q) - 1));
					return true;
				}else{
					$sender->sendMessage("Wrong answer.");
					return false;
				}
		}
		return false;
	}
}